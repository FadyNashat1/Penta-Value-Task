const BaseUrl = 'https://api.coingecko.com/api/v3/';
export default BaseUrl;
