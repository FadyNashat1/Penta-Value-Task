// tani khatwa
export const REDUX_TODOLIST = 'TODOLIST';
export const REDUX_DELTODOLIST = 'DELTODOLIST';
export const REDUX_LOGIN = 'LOGIN';
export const REDUX_lOGOUT = 'lOGOUT';